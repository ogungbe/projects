interface SendMessage {
    boolean send(Activity activity);
}
