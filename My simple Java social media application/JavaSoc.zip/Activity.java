interface Activity {
    String getURI();
}
