interface ReadNextMessage {
    Activity readNext();
}
