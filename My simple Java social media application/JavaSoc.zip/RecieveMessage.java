interface ReceiveMessage {
    boolean receive(Activity activity);
}
