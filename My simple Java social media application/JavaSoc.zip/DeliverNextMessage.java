interface DeliverNextMessage {
    Activity deliverNext();
}
