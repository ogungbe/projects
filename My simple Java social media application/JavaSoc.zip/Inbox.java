interface Inbox extends ReceiveMessage, ReadNextMessage {
    int getCount();
}
